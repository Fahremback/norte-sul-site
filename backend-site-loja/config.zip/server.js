

// Carrega variáveis de ambiente do arquivo .env apenas se não estiver em produção
if (process.env.NODE_ENV !== 'production') {
  require('dotenv').config();
}
const express = require('express');
const cors = require('cors');
const path = require('path');
const { loadConfig } = require('./lib/config');
const { PrismaClient } = require('@prisma/client');
const { hashPassword } = require('./utils/passwordUtils');
const errorHandler = require('./middleware/errorHandler');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const prisma = new PrismaClient();

// --- Self-healing mechanism for admin user ---
async function ensureAdminUserExists() {
    const adminEmail = 'nortesulinformaticaloja@gmail.com';
    try {
        const adminUser = await prisma.user.findUnique({
            where: { email: adminEmail },
        });

        if (!adminUser) {
            console.log('Admin user not found. Creating default admin user...');
            const hashedPassword = await hashPassword('3578P1687r@');
            await prisma.user.create({
                data: {
                    email: adminEmail,
                    username: 'admin',
                    name: 'Admin da Loja',
                    password: hashedPassword,
                    isAdmin: true,
                    emailVerified: true, // Pre-verify the default admin
                },
            });
            console.log('✅ Default admin user created successfully.');
        } else {
             console.log('✅ Default admin user already exists.');
        }
    } catch (error) {
        console.error('❌ CRITICAL ERROR: Could not ensure admin user exists.', error);
        // This might fail if the DB isn't connected, but server start will also fail later.
        // It's important to see this error.
    }
}


// Rotas
const productRoutes = require('./routes/products');
const courseRoutes = require('./routes/courses');
const authRoutes = require('./routes/auth');
const settingsRoutes = require('./routes/settings');
const paymentRoutes = require('./routes/payment');
const planRoutes = require('./routes/plans');
const orderRoutes = require('./routes/orders');
const userRoutes = require('./routes/users');
const subscriptionRoutes = require('./routes/subscriptions');
const addressRoutes = require('./routes/addresses');
const ticketRoutes = require('./routes/tickets');
const uploadRoutes = require('./routes/upload');
const pendingServiceRoutes = require('./routes/pending-services');
const purchaseRequestRoutes = require('./routes/purchase-requests');
const configRoutes = require('./routes/config');

const app = express();

const startServer = async () => {
    // Carrega a configuração do banco de dados antes de iniciar o servidor
    await loadConfig(); 
    
    // Garante que o usuário admin exista antes de o servidor começar a aceitar requisições
    await ensureAdminUserExists();

    const PORT = process.env.PORT || 3001;

    // --- Middlewares ---
    
    // Confia no primeiro proxy (essencial para rate-limiting em ambientes como Render, Heroku, etc.)
    app.set('trust proxy', 1);

    // Política de Segurança de Conteúdo (CSP) reativada com configuração mais permissiva e segura.
    app.use(
      helmet({
        contentSecurityPolicy: {
          directives: {
            ...helmet.contentSecurityPolicy.getDefaultDirectives(),
            'default-src': ["'self'"],
            'script-src': ["'self'", "'unsafe-eval'"], // 'unsafe-eval' é necessário para bibliotecas como Recharts.
            'style-src': ["'self'", 'https://fonts.googleapis.com', "'unsafe-inline'"],
            'font-src': ["'self'", 'https://fonts.gstatic.com'],
            'img-src': ["'self'", 'data:', 'blob:', 'https://via.placeholder.com', 'https://images.unsplash.com'],
            'connect-src': ["'self'"],
            'worker-src': ["'self'", "blob:"],
            'object-src': ["'none'"],
            'frame-ancestors': ["'none'"],
          },
        },
      })
    );

    app.use(cors());
    app.use('/api/payment/webhook/asaas-confirmation', express.raw({ type: 'application/json' }), paymentRoutes);
    app.use(express.json({ limit: '10mb' }));
    app.use(express.urlencoded({ extended: true, limit: '10mb' }));

    // Rate Limiter para endpoints públicos e sensíveis
    const apiLimiter = rateLimit({
        windowMs: 15 * 60 * 1000, // 15 minutos
        max: 100, // Limita cada IP a 100 requisições por janela
        standardHeaders: true, // Retorna informações nos headers `RateLimit-*`
        legacyHeaders: false, // Desabilita os headers `X-RateLimit-*`
        message: { message: 'Muitas requisições desta origem, por favor tente novamente em 15 minutos.' }
    });

    // Aplica o rate limiter a rotas específicas
    app.use('/api/auth', apiLimiter);
    app.use('/api/tickets', apiLimiter);


    // Servir arquivos estáticos da pasta 'uploads'
    app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

    // Usar as Rotas da API
    app.use('/api/products', productRoutes);
    app.use('/api/courses', courseRoutes);
    app.use('/api/auth', authRoutes);
    app.use('/api/settings', settingsRoutes);
    app.use('/api/payment', paymentRoutes);
    app.use('/api/plans', planRoutes);
    app.use('/api/orders', orderRoutes);
    app.use('/api/users', userRoutes);
    app.use('/api/subscriptions', subscriptionRoutes);
    app.use('/api/addresses', addressRoutes);
    app.use('/api/tickets', ticketRoutes);
    app.use('/api/upload', uploadRoutes);
    app.use('/api/pending-services', pendingServiceRoutes);
    app.use('/api/purchase-requests', purchaseRequestRoutes);
    app.use('/api/config', configRoutes);

    // --- Servir o Frontend em Produção ---
    // Ajustado para procurar a pasta 'dist' no diretório raiz do projeto
    const frontendDistPath = path.join(__dirname, '..', 'dist');

    // Verifica se a pasta 'dist' existe
    if (require('fs').existsSync(frontendDistPath)) {
        app.use(express.static(frontendDistPath));

        // Catch-all para servir o index.html para qualquer rota não-API (suporte ao React Router)
        app.get('*', (req, res, next) => {
            if (req.path.startsWith('/api/')) {
                return next(); // Deixa a API lidar com 404s de API
            }
            res.sendFile(path.join(frontendDistPath, 'index.html'));
        });
    } else {
        console.warn(`
            ****************************************************************************
            AVISO: O diretório de build do frontend não foi encontrado em:
            ${frontendDistPath}
            O servidor backend está rodando, mas não poderá servir o site.
            Execute 'npm run build' no diretório raiz do frontend.
            ****************************************************************************
        `);
        // Adiciona um fallback para que o servidor não quebre se o frontend não estiver buildado
        app.get('*', (req, res, next) => {
            if (req.path.startsWith('/api/')) {
                return next();
            }
            res.status(404).send('Frontend não encontrado. Execute o build do frontend.');
        });
    }

    // Centralized Error Handler - must be the last middleware
    app.use(errorHandler);

    app.listen(PORT, () => {
        console.log(`Backend server ouvindo na porta ${PORT}`);
        console.log("==================================================================================");
        console.log(" ✅ Servidor Backend Iniciado com Sucesso!");
        console.log("==================================================================================");
        console.log(" 🚀 Configuração Inicial:");
        console.log("    1. DATABASE_URL: Verifique se a string de conexão com o PostgreSQL está no .env.");
        console.log("    2. Rode 'npm run db:reset' para criar e popular o banco de dados.");
        console.log("----------------------------------------------------------------------------------");
        console.log(" 🔑 Configurações Avançadas (Asaas, E-mail, JWT):");
        console.log("    -> Devem ser configuradas no Painel de Administração do site após o login.");
        console.log("    -> Painel Admin > Config. Site.");
        console.log("----------------------------------------------------------------------------------");
        console.log(" 🔑 Usuário Admin Padrão: nortesulinformaticaloja@gmail.com / 3578P1687r@");
        console.log("==================================================================================");
    });
};

startServer().catch(error => {
    console.error("Falha ao iniciar o servidor:", error);
    process.exit(1);
});