// backend/middleware/errorHandler.js
const { ZodError } = require('zod');
const { Prisma } = require('@prisma/client');

const errorHandler = (err, req, res, next) => {
  console.error("ERROR-HANDLER:", err);

  if (err instanceof ZodError) {
    return res.status(400).json({ 
      message: 'Erro de validação.', 
      errors: err.errors.map(e => ({ path: e.path, message: e.message }))
    });
  }

  if (err instanceof Prisma.PrismaClientKnownRequestError) {
    if (err.code === 'P2002') {
      return res.status(409).json({ message: `Conflito: o registro com o campo '${err.meta.target.join(', ')}' já existe.` });
    }
    if (err.code === 'P2025') {
      return res.status(404).json({ message: 'Recurso não encontrado.' });
    }
  }

  const statusCode = err.statusCode || 500;
  const message = err.message || 'Ocorreu um erro interno no servidor.';

  res.status(statusCode).json({ message });
};

module.exports = errorHandler;
