const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authMiddleware, adminMiddleware } = require('../middleware/authMiddleware');

const prisma = new PrismaClient();
const router = express.Router();

// GET: Fetch all expenses for the current user
router.get('/', authMiddleware, async (req, res) => {
    try {
        const expenses = await prisma.expense.findMany({
            where: { userId: req.user.id },
            orderBy: { date: 'desc' },
        });
        res.json(expenses.map(e => ({...e, amount: Number(e.amount)})));
    } catch (error) {
        res.status(500).json({ message: 'Falha ao buscar despesas.' });
    }
});

// POST: Create a new expense
router.post('/', authMiddleware, async (req, res) => {
    const { description, amount, category, date } = req.body;
    if (!description || !amount) {
        return res.status(400).json({ message: 'Descrição e valor são obrigatórios.' });
    }
    try {
        const newExpense = await prisma.expense.create({
            data: {
                description,
                amount: parseFloat(amount),
                category: category || 'Outras',
                date: date ? new Date(date) : new Date(),
                userId: req.user.id
            },
        });
        res.status(201).json({...newExpense, amount: Number(newExpense.amount)});
    } catch (error) {
        console.error("Error creating expense:", error);
        res.status(400).json({ message: 'Não foi possível criar a despesa.' });
    }
});

// PUT: Update an expense (admin only for now, can be adjusted)
router.put('/:id', authMiddleware, adminMiddleware, async (req, res) => {
    const { id } = req.params;
    const { description, amount, category, date } = req.body;
    try {
        const updatedExpense = await prisma.expense.update({
            where: { id },
            data: {
                description,
                amount: parseFloat(amount),
                category,
                date: date ? new Date(date) : undefined,
            },
        });
        res.json({...updatedExpense, amount: Number(updatedExpense.amount)});
    } catch (error) {
        if (error.code === 'P2025') return res.status(404).json({ message: 'Despesa não encontrada.' });
        res.status(400).json({ message: 'Dados inválidos para atualização.' });
    }
});

// DELETE: Delete an expense (admin only for now, can be adjusted)
router.delete('/:id', authMiddleware, adminMiddleware, async (req, res) => {
    const { id } = req.params;
    try {
        await prisma.expense.delete({ where: { id } });
        res.status(204).send();
    } catch (error) {
        if (error.code === 'P2025') return res.status(404).json({ message: 'Despesa não encontrada.' });
        res.status(500).json({ message: 'Falha ao deletar despesa.' });
    }
});

module.exports = router;
