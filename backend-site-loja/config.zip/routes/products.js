

const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authMiddleware, adminMiddleware } = require('../middleware/authMiddleware');
const sharp = require('sharp');
const path = require('path');
const fs = require('fs');

const prisma = new PrismaClient();
const router = express.Router();

async function saveImageFromBase64(imageBase64) {
    if (!imageBase64) return null;
    
    try {
        const buffer = Buffer.from(imageBase64, 'base64');
        const uploadsDir = path.join(__dirname, '..', 'uploads');
        if (!fs.existsSync(uploadsDir)) {
            fs.mkdirSync(uploadsDir, { recursive: true });
        }
        
        const filename = `${Date.now()}-product.webp`;
        const filepath = path.join(uploadsDir, filename);

        await sharp(buffer)
            .resize({ width: 800, height: 800, fit: 'inside', withoutEnlargement: true })
            .webp({ quality: 80 })
            .toFile(filepath);

        return `/uploads/${filename}`;
    } catch (error) {
        console.error("Failed to save image from base64:", error);
        return null;
    }
}

const convertPriceToNumber = (item) => {
    if (item && item.price) {
        const newItem = { ...item, price: Number(item.price) };
        if (item.storePrice) {
            newItem.storePrice = Number(item.storePrice);
        }
        return newItem;
    }
    return item;
};

router.get('/', async (req, res) => {
    try {
        const products = await prisma.product.findMany({
            orderBy: { createdAt: 'desc' },
        });
        res.json(products.map(convertPriceToNumber));
    } catch (error) {
        console.error("Erro ao buscar produtos:", error);
        res.status(500).json({ message: 'Falha ao buscar produtos.' });
    }
});

router.post('/bulk', authMiddleware, adminMiddleware, async (req, res) => {
    const products = req.body;

    if (!Array.isArray(products) || products.length === 0) {
        return res.status(400).json({ message: 'O corpo da requisição deve ser um array de produtos.' });
    }

    try {
        const dataToCreate = [];
        for (const p of products) {
            let finalImageUrl = p.imageUrl || null;
            if (p.imageBase64) {
                finalImageUrl = await saveImageFromBase64(p.imageBase64);
            }
            dataToCreate.push({
                name: p.name,
                description: p.description || '',
                price: parseFloat(String(p.price)) || 0,
                storePrice: p.storePrice != null ? parseFloat(String(p.storePrice)) : undefined,
                imageUrl: finalImageUrl,
                category: p.category || 'Geral',
                stock: p.quantity !== undefined ? parseInt(String(p.quantity), 10) : 0,
                sku: p.sku || null,
                status: p.status || 'pending_details'
            });
        }

        const result = await prisma.product.createMany({
            data: dataToCreate,
            skipDuplicates: true, 
        });

        res.status(201).json({
            message: `${result.count} de ${products.length} produtos foram adicionados com sucesso.`,
            count: result.count,
        });

    } catch (error) {
        console.error('Erro ao adicionar produtos em lote:', error);
        res.status(500).json({ message: 'Ocorreu um erro no servidor ao tentar adicionar os produtos.' });
    }
});

router.delete('/bulk', authMiddleware, adminMiddleware, async (req, res) => {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ message: 'O corpo da requisição deve ser um array de IDs.' });
    }
    try {
        const result = await prisma.$transaction(async (tx) => {
            await tx.orderItem.deleteMany({
                where: { productId: { in: ids } }
            });
            return await tx.product.deleteMany({
                where: { id: { in: ids } }
            });
        });
        res.status(200).json({ message: `${result.count} produtos deletados com sucesso.`, count: result.count });
    } catch (error) {
        console.error('Erro ao deletar produtos em lote:', error);
        res.status(500).json({ message: 'Ocorreu um erro no servidor ao tentar deletar os produtos.' });
    }
});

router.get('/:id', async (req, res) => {
    try {
        const product = await prisma.product.findUnique({
            where: { id: req.params.id },
        });
        if (product) {
            res.json(convertPriceToNumber(product));
        } else {
            res.status(404).json({ message: 'Produto não encontrado.' });
        }
    } catch (error) {
        console.error(`Erro ao buscar produto ${req.params.id}:`, error);
        res.status(500).json({ message: 'Falha ao buscar o produto.' });
    }
});

router.post('/', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const { name, description, price, storePrice, imageUrl, category, stock, quantity, sku, status, imageBase64 } = req.body;

        if (!name || (price === undefined && storePrice === undefined) || !category) {
            return res.status(400).json({ message: 'Nome, preço e categoria são campos obrigatórios.' });
        }

        let finalImageUrl = imageUrl;
        if (imageBase64) {
            finalImageUrl = await saveImageFromBase64(imageBase64);
        }

        const newProduct = await prisma.product.create({
            data: {
                name,
                description: description || '',
                price: parseFloat(String(price || 0)),
                storePrice: storePrice != null ? parseFloat(String(storePrice)) : undefined,
                imageUrl: finalImageUrl,
                category,
                stock: stock !== undefined ? parseInt(String(stock), 10) : (quantity !== undefined ? parseInt(String(quantity), 10) : 0),
                quantity: stock !== undefined ? parseInt(String(stock), 10) : (quantity !== undefined ? parseInt(String(quantity), 10) : 0),
                sku: sku || null,
                status: status || 'pending_details',
            },
        });
        res.status(201).json(convertPriceToNumber(newProduct));
    } catch (error) {
        console.error("Erro ao criar produto:", error);
        if (error.code === 'P2002' && error.meta?.target?.includes('sku')) {
            return res.status(400).json({ message: `O SKU "${req.body.sku}" já está em uso.` });
        }
        res.status(400).json({ message: 'Não foi possível criar o produto. Verifique os dados enviados.' });
    }
});

router.put('/:id', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const { name, description, price, storePrice, imageUrl, category, stock, quantity, sku, status, imageBase64 } = req.body;
        
        const dataToUpdate = {
            name, description, status,
            price: parseFloat(String(price)),
            storePrice: storePrice != null ? parseFloat(String(storePrice)) : undefined,
            category,
            stock: stock !== undefined ? parseInt(String(stock), 10) : (quantity !== undefined ? parseInt(String(quantity), 10) : 0),
            quantity: stock !== undefined ? parseInt(String(stock), 10) : (quantity !== undefined ? parseInt(String(quantity), 10) : 0),
            sku,
        };

        if (imageBase64) {
            dataToUpdate.imageUrl = await saveImageFromBase64(imageBase64);
        } else if (imageUrl !== undefined) { 
            dataToUpdate.imageUrl = imageUrl;
        }

        const updatedProduct = await prisma.product.update({
            where: { id: req.params.id },
            data: dataToUpdate,
        });
        res.json(convertPriceToNumber(updatedProduct));
    } catch (error) {
        console.error(`Erro ao atualizar produto ${req.params.id}:`, error);
        if (error.code === 'P2025') { 
            return res.status(404).json({ message: 'Produto não encontrado para atualização.' });
        }
         if (error.code === 'P2002' && error.meta?.target?.includes('sku')) {
            return res.status(400).json({ message: `O SKU "${req.body.sku}" já está em uso por outro produto.` });
        }
        res.status(400).json({ message: 'Dados inválidos para atualização do produto.' });
    }
});

router.delete('/:id', authMiddleware, adminMiddleware, async (req, res) => {
    const productId = req.params.id;
    try {
        await prisma.$transaction(async (tx) => {
            await tx.orderItem.deleteMany({ where: { productId: productId } });
            await tx.product.delete({ where: { id: productId } });
        });
        res.status(204).send();
    } catch (error) {
        console.error(`Erro ao deletar produto ${productId}:`, error);
        if (error.code === 'P2025') {
            return res.status(404).json({ message: 'Produto não encontrado para exclusão.' });
        }
        res.status(500).json({ message: 'Falha ao deletar o produto.' });
    }
});

module.exports = router;
