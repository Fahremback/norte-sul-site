const express = require('express');
const { PrismaClient } = require('@prisma/client');
const axios = require('axios');
const { authMiddleware } = require('../middleware/authMiddleware');
const { getConfig } = require('../lib/config');

const prisma = new PrismaClient();
const router = express.Router();

async function findOrCreateAsaasCustomer(user, asaasApiKey) {
    if (user.asaasCustomerId) {
        try {
            const response = await axios.get(`https://www.asaas.com/api/v3/customers/${user.asaasCustomerId}`, { headers: { 'access_token': asaasApiKey } });
            return response.data.id;
        } catch (error) {
            console.warn(`Asaas customer ID ${user.asaasCustomerId} not found. Creating a new one.`);
        }
    }

    try {
        const response = await axios.post('https://www.asaas.com/api/v3/customers', {
            name: user.name,
            email: user.email,
            cpfCnpj: user.cpfCnpj,
            externalReference: user.id
        }, { headers: { 'access_token': asaasApiKey } });
        
        await prisma.user.update({
            where: { id: user.id },
            data: { asaasCustomerId: response.data.id }
        });
        
        return response.data.id;
    } catch (error) {
        if (error.response?.data?.errors?.some(e => e.code === 'invalid_cpfCnpj')) {
            const searchResponse = await axios.get(`https://www.asaas.com/api/v3/customers?cpfCnpj=${user.cpfCnpj}`, { headers: { 'access_token': asaasApiKey }});
            if (searchResponse.data?.data?.length > 0) {
                const customerId = searchResponse.data.data[0].id;
                 await prisma.user.update({
                    where: { id: user.id },
                    data: { asaasCustomerId: customerId }
                });
                return customerId;
            }
        }
        console.error("Asaas customer creation/fetch error:", error.response ? error.response.data : error.message);
        throw new Error('Falha na comunicação com o provedor de pagamento para registrar o cliente.');
    }
}

router.post('/initiate', authMiddleware, async (req, res) => {
    const { cartItems, totalAmount, paymentMethod, address, buyerInfo, creditCard, creditCardHolderInfo } = req.body;
    const userId = req.user.id;

    if (!cartItems || cartItems.length === 0 || !totalAmount || !paymentMethod || !address || !buyerInfo) {
        return res.status(400).json({ message: 'Dados do pedido, endereço ou comprador inválidos.' });
    }
    
    try {
        const config = getConfig();
        const asaasApiKey = config.asaasApiKey;

        if (!asaasApiKey) {
            return res.status(500).json({ message: 'Chave da API de pagamento não configurada no servidor.' });
        }
        
        const userWithData = await prisma.user.findUnique({ where: { id: userId } });
        if(!userWithData) throw new Error("Usuário não encontrado.");
        
        const customerDataForAsaas = { id: userWithData.id, asaasCustomerId: userWithData.asaasCustomerId, name: buyerInfo.name, email: buyerInfo.email, cpfCnpj: buyerInfo.cpfCnpj };
        const customerId = await findOrCreateAsaasCustomer(customerDataForAsaas, asaasApiKey);

        const order = await prisma.order.create({
            data: {
                userId, totalAmount, status: 'PENDING', paymentMethod,
                customerName: buyerInfo.name, customerEmail: buyerInfo.email, customerCpfCnpj: buyerInfo.cpfCnpj,
                shippingAddress: `${address.street}, ${address.number} ${address.complement || ''}`,
                shippingCity: address.city, shippingState: address.state, shippingPostalCode: address.cep,
                items: {
                    create: cartItems.map(item => ({
                        productId: item.itemType === 'PRODUCT' ? item.id : undefined,
                        courseId: item.itemType === 'COURSE' ? item.id : undefined,
                        quantity: item.quantity, price: item.price,
                    })),
                },
            },
        });

        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);

        const paymentPayload = {
            customer: customerId, billingType: paymentMethod, value: totalAmount,
            dueDate: tomorrow.toISOString().split('T')[0],
            description: `Pedido #${order.id} - ${config.siteName || 'Norte Sul Informática'}`,
            externalReference: order.id,
        };
        
        if (paymentMethod === 'CREDIT_CARD') {
            paymentPayload.creditCard = { holderName: creditCard.holderName, number: creditCard.number.replace(/\s/g, ''), expiryMonth: creditCard.expiryMonth, expiryYear: creditCard.expiryYear, ccv: creditCard.ccv };
            paymentPayload.creditCardHolderInfo = { name: creditCardHolderInfo.name, email: creditCardHolderInfo.email, cpfCnpj: creditCardHolderInfo.cpfCnpj, postalCode: creditCardHolderInfo.postalCode, addressNumber: creditCardHolderInfo.addressNumber, phone: creditCardHolderInfo.phone };
        }

        const paymentResponse = await axios.post('https://www.asaas.com/api/v3/payments', paymentPayload, { headers: { 'access_token': asaasApiKey } });
        const paymentData = paymentResponse.data;
        
        await prisma.order.update({ where: { id: order.id }, data: { paymentId: paymentData.id, status: paymentData.status } });

        const responsePayload = { orderId: order.id, status: paymentData.status, method: paymentMethod, message: `Cobrança via ${paymentMethod} gerada.`};
        if (paymentMethod === 'PIX') responsePayload.pixCopiaCola = paymentData.pixQrCode.payload;
        if (paymentMethod === 'BOLETO') responsePayload.boletoUrl = paymentData.bankSlipUrl;

        res.json(responsePayload);

    } catch (error) {
        const errorMessage = error.response ? JSON.stringify(error.response.data) : error.message;
        console.error('Erro ao criar pagamento:', errorMessage);
        res.status(500).json({ message: `Falha ao criar cobrança. Detalhes: ${errorMessage}` });
    }
});

router.get('/:paymentId/details', authMiddleware, async (req, res) => {
    const { paymentId } = req.params;
    const { user } = req;

    try {
        const { asaasApiKey } = getConfig();
        if (!asaasApiKey) return res.status(500).json({ message: 'Chave da API de pagamento não configurada.' });

        const order = await prisma.order.findFirst({ where: { paymentId, userId: user.id } });
        if (!order) return res.status(404).json({ message: 'Detalhes de pagamento não encontrados ou acesso não permitido.' });

        const response = await axios.get(`https://www.asaas.com/api/v3/payments/${paymentId}`, { headers: { 'access_token': asaasApiKey } });
        res.json(response.data);
    } catch (error) {
        const errorMessage = error.response ? JSON.stringify(error.response.data) : error.message;
        res.status(500).json({ message: `Falha ao buscar detalhes do pagamento. Detalhes: ${errorMessage}` });
    }
});

router.post('/webhook/asaas-confirmation', async (req, res) => {
    const { event, payment, subscription } = req.body;
    if (!event || (!payment && !subscription)) return res.status(400).send('Corpo do webhook inválido.');

    const entity = payment || subscription;
    const asaasId = entity.id;

    try {
        if(payment) {
            const orderId = entity.externalReference;
            if (!orderId) return res.status(400).send('Referência externa não encontrada no webhook.');
            
            const order = await prisma.order.findUnique({ where: { id: orderId } });
            if (!order) return res.status(404).send('Pedido não encontrado.');
            if (order.status === 'PAID') return res.status(200).send('Pedido já processado.');
            
            let newStatus = order.status;
            if (event === 'PAYMENT_CONFIRMED' || event === 'PAYMENT_RECEIVED') newStatus = 'PAID';
            else if (['PAYMENT_OVERDUE', 'PAYMENT_DELETED'].includes(event)) newStatus = 'CANCELED';
            
            if (newStatus !== order.status) {
                await prisma.order.update({ where: { id: orderId }, data: { status: newStatus } });
            }
        } else if (subscription) {
             const sub = await prisma.subscription.findFirst({ where: { asaasSubscriptionId: asaasId } });
             if (sub) await prisma.subscription.update({ where: { id: sub.id }, data: { status: entity.status, nextDueDate: new Date(entity.nextDueDate) } });
        }
        res.status(200).send('Webhook processado.');
    } catch (error) {
        console.error('Erro ao processar webhook do Asaas:', error);
        res.status(500).send('Erro interno ao processar webhook.');
    }
});

module.exports = router;
