
const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authMiddleware, adminMiddleware } = require('../middleware/authMiddleware');
const { reloadConfig } = require('../lib/config');

const prisma = new PrismaClient();
const router = express.Router();

// GET /api/config/gemini-key - Admin only
router.get('/gemini-key', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const settings = await prisma.siteSettings.findUnique({
            where: { id: 'singleton' },
            select: { geminiApiKey: true },
        });
        res.json({ apiKey: settings?.geminiApiKey || '' });
    } catch (error) {
        res.status(500).json({ message: 'Failed to fetch Gemini API key.' });
    }
});

// PUT /api/config/gemini-key - Admin only
router.put('/gemini-key', authMiddleware, adminMiddleware, async (req, res) => {
    const { apiKey } = req.body;

    try {
        await prisma.siteSettings.upsert({
            where: { id: 'singleton' },
            update: { geminiApiKey: apiKey },
            create: { id: 'singleton', geminiApiKey: apiKey },
        });

        // Reload config cache in the backend
        await reloadConfig();

        res.json({ message: 'Gemini API key updated successfully.' });
    } catch (error) {
        res.status(500).json({ message: 'Failed to update Gemini API key.' });
    }
});

module.exports = router;
