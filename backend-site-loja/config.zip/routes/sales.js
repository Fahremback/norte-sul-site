
const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authMiddleware, adminMiddleware } = require('../middleware/authMiddleware');

const prisma = new PrismaClient();
const router = express.Router();

// GET: Fetch all sales for the current user
router.get('/', authMiddleware, async (req, res) => {
    try {
        const sales = await prisma.saleTransaction.findMany({
            where: { userId: req.user.id },
            orderBy: { date: 'desc' },
        });
        res.json(sales.map(s => ({...s, totalAmount: Number(s.totalAmount), pricePerItem: Number(s.pricePerItem) })));
    } catch (error) {
        res.status(500).json({ message: 'Falha ao buscar vendas.' });
    }
});

// POST: Create a new sale and update product stock if applicable
router.post('/', authMiddleware, async (req, res) => {
    const { itemId, itemType, itemName, quantitySold, pricePerItem, totalAmount, date } = req.body;

    try {
        const result = await prisma.$transaction(async (tx) => {
            if (itemType === 'product' && itemId) {
                const product = await tx.product.findUnique({ where: { id: itemId } });
                if (!product || product.stock < quantitySold) {
                    throw new Error('Estoque insuficiente.');
                }
                await tx.product.update({
                    where: { id: itemId },
                    data: { stock: { decrement: quantitySold } },
                });
            }
            
            const newSale = await tx.saleTransaction.create({
                data: {
                    productId: itemType === 'product' ? itemId : null,
                    serviceId: itemType === 'service' ? itemId : null,
                    itemName,
                    quantitySold: parseInt(quantitySold, 10),
                    pricePerItem: parseFloat(pricePerItem),
                    totalAmount: parseFloat(totalAmount),
                    date: date ? new Date(date) : new Date(),
                    userId: req.user.id
                },
            });

            return newSale;
        });

        res.status(201).json({...result, totalAmount: Number(result.totalAmount), pricePerItem: Number(result.pricePerItem)});
    } catch (error) {
        console.error("Error creating sale:", error);
        res.status(400).json({ message: error.message || 'Não foi possível registrar a venda.' });
    }
});

// PUT: Update a sale and adjust stock accordingly (admin only)
router.put('/:id', authMiddleware, adminMiddleware, async (req, res) => {
    const { id } = req.params;
    const { itemName, quantitySold, pricePerItem, totalAmount, date } = req.body;

    try {
        const result = await prisma.$transaction(async (tx) => {
            const originalSale = await tx.saleTransaction.findUnique({ where: { id } });
            if (!originalSale) {
                throw new Error('Venda original não encontrada.');
            }

            const quantityDifference = quantitySold - originalSale.quantitySold;

            let updatedProduct = null;
            if (originalSale.productId) {
                const product = await tx.product.findUnique({ where: { id: originalSale.productId } });
                if (!product) {
                    throw new Error('Produto associado à venda não encontrado.');
                }
                if (product.stock < quantityDifference) {
                    throw new Error('Ajuste de estoque excede a quantidade disponível.');
                }
                updatedProduct = await tx.product.update({
                    where: { id: originalSale.productId },
                    data: { stock: { decrement: quantityDifference } },
                });
            }

            const updatedSale = await tx.saleTransaction.update({
                where: { id },
                data: {
                    itemName,
                    quantitySold: parseInt(quantitySold, 10),
                    pricePerItem: parseFloat(pricePerItem),
                    totalAmount: parseFloat(pricePerItem) * parseInt(quantitySold, 10),
                    date: date ? new Date(date) : undefined,
                },
            });
             return { updatedSale, updatedProduct };
        });

        const serializedSale = {
            ...result.updatedSale,
            totalAmount: Number(result.updatedSale.totalAmount),
            pricePerItem: Number(result.updatedSale.pricePerItem)
        };
        const serializedProduct = result.updatedProduct ? { ...result.updatedProduct, price: Number(result.updatedProduct.price), storePrice: Number(result.updatedProduct.storePrice) } : null;

        res.json({ ...serializedSale, updatedProduct: serializedProduct });

    } catch (error) {
        console.error("Error updating sale:", error);
        res.status(400).json({ message: error.message || 'Falha ao atualizar a venda.' });
    }
});


// DELETE: Delete a sale and revert product stock (admin only)
router.delete('/:id', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const result = await prisma.$transaction(async (tx) => {
            const saleToDelete = await tx.saleTransaction.findUnique({ where: { id: req.params.id } });
            if (!saleToDelete) {
                throw new Error('Venda não encontrada.');
            }

            let updatedProduct = null;
            if (saleToDelete.productId) {
                 updatedProduct = await tx.product.update({
                    where: { id: saleToDelete.productId },
                    data: { stock: { increment: saleToDelete.quantitySold } },
                });
            }

            await tx.saleTransaction.delete({ where: { id: req.params.id } });

            return { updatedProduct };
        });
        
        res.status(200).json({
            message: 'Venda excluída com sucesso',
            updatedProduct: result.updatedProduct ? { ...result.updatedProduct, price: Number(result.updatedProduct.price), storePrice: Number(result.updatedProduct.storePrice) } : null
        });

    } catch (error) {
        if (error.message === 'Venda não encontrada.') return res.status(404).json({ message: error.message });
        console.error(`Error deleting sale ${req.params.id}:`, error);
        res.status(500).json({ message: 'Falha ao deletar a venda.' });
    }
});


module.exports = router;
