const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authMiddleware } = require('../middleware/authMiddleware');

const prisma = new PrismaClient();
const router = express.Router();

// GET all services
router.get('/', authMiddleware, async (req, res) => {
    try {
        const services = await prisma.service.findMany({
            orderBy: { name: 'asc' },
        });
        res.json(services.map(s => ({...s, price: Number(s.price) })));
    } catch (error) {
        console.error("Error fetching services:", error);
        res.status(500).json({ message: 'Falha ao buscar serviços.' });
    }
});

// Note: Add/Edit/Delete for pre-defined services would go here if needed in the future.
// For now, they are managed via seed or Prisma Studio.

module.exports = router;
