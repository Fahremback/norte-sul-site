# Norte Sul Informática - Backend

Este repositório contém o código-fonte para o backend (Node.js + Express + Prisma) da aplicação Norte Sul Informática.

## 🚀 Guia de Instalação Rápida

Siga **exatamente** estes passos para rodar o backend localmente.

### Pré-requisitos

*   **Node.js**: Versão 18 ou superior.
*   **npm**: Instalado com o Node.js.
*   **PostgreSQL**: Instalado e rodando na sua máquina.

---

### Passo 1: Navegue para a Pasta do Backend

Abra seu terminal e certifique-se de que você está **dentro da pasta `backend-site-loja`**:

```bash
cd backend-site-loja
```

### Passo 2: Instale as Dependências do Backend

Este é o passo mais comum onde ocorrem erros. Execute o seguinte comando **dentro da pasta `backend-site-loja`**:

```bash
npm install
```

**Se você ver um erro como `Error: Cannot find module 'helmet'`, significa que este passo não foi executado ou falhou. Execute-o novamente.**

### Passo 3: Configure o Banco de Dados

1.  Crie um arquivo chamado `.env` na raiz da pasta `backend-site-loja`.
2.  Copie o conteúdo abaixo para o seu arquivo `.env` e **substitua os valores** com as credenciais do seu PostgreSQL.

    ```env
    # Substitua com seus dados reais de conexão com o PostgreSQL
    # Exemplo: postgresql://postgres:mysecretpassword@localhost:5432/nortesuldb?schema=public
    DATABASE_URL="postgresql://SEU_USUARIO:SUA_SENHA@localhost:5432/NOME_DO_BANCO?schema=public"
    ```

### Passo 4: Crie e Popule o Banco de Dados

Este comando irá criar todas as tabelas e adicionar dados iniciais (como o usuário admin).

```bash
npm run db:reset
```

### Passo 5: Inicie o Servidor

```bash
npm run dev
```

O servidor deve iniciar com sucesso e estará rodando em `http://localhost:3001`.
