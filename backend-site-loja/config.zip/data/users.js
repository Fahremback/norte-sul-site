// backend/data/users.js
// Os usuários agora são gerenciados pelo banco de dados PostgreSQL via Prisma.
// Para criar um usuário administrador inicial, use o "seeding" do Prisma.
// Veja as instruções sobre como criar e rodar `prisma/seed.js`.

const users = []; // Não mais usado diretamente, mas pode ser útil para referência em seeds.

module.exports = users; // Exporta array vazio ou remove o arquivo se não for mais referenciado.
