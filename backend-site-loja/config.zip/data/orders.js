// backend/data/orders.js
// Os pedidos agora são gerenciados pelo banco de dados PostgreSQL via Prisma.

let orders = []; // Array em memória não é mais a fonte primária.
module.exports = orders;
