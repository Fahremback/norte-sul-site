// backend/data/courses.js
// Os cursos agora são gerenciados pelo banco de dados PostgreSQL via Prisma.
// Para adicionar cursos iniciais, use o "seeding" do Prisma ou a interface de admin (se implementada).

let courses = []; // Array em memória não é mais a fonte primária.
module.exports = courses;
