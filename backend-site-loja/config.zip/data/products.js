// backend/data/products.js
// Os produtos agora são gerenciados pelo banco de dados PostgreSQL via Prisma.
// Para adicionar produtos iniciais, use o "seeding" do Prisma ou a interface de admin.

let products = []; // Array em memória não é mais a fonte primária.
module.exports = products;
